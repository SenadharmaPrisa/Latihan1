package com.example.latihan1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        val btnbasesatu = findViewById<Button>(R.id.btnbs1)
        val btnbasedua = findViewById<Button>(R.id.btnbs2)
        val btnbasetiga = findViewById<Button>(R.id.btnbs3)

        btnbasesatu.setOnClickListener {
            val intent = Intent(this, BaseSatu::class.java)
            startActivity(intent)
        }

        btnbasedua.setOnClickListener {
            val intent = Intent(this, BaseDua::class.java)
            startActivity(intent)
        }

        btnbasetiga.setOnClickListener {
             val intent = Intent(this, BaseTiga::class.java)
            startActivity(intent)
         }
    }
}

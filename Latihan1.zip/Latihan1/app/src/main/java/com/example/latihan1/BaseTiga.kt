package com.example.latihan1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class BaseTiga : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.basetiga)

        val etBeratBadan = findViewById<EditText>(R.id.editTextTiga1)
        val etTinggiBadan = findViewById<EditText>(R.id.editTextTiga2)
        val btnHitung = findViewById<Button>(R.id.btnhtng)
        val tvHasilBmi = findViewById<TextView>(R.id.tvHasilBmiTiga)
        val tvKategoriBmi = findViewById<TextView>(R.id.tvKategoriBmiTiga)

        val btnKembali = findViewById<Button>(R.id.btnback)
        btnKembali.setOnClickListener {
            finish()
        }

        btnHitung.setOnClickListener {
            val beratStr = etBeratBadan.text.toString()
            val tinggiStr = etTinggiBadan.text.toString()

            if (beratStr.isNotEmpty() && tinggiStr.isNotEmpty()) {
                val berat = beratStr.toFloat()
                val tinggiCm = tinggiStr.toFloat()

                val tinggiM = tinggiCm / 100

                val bmi = berat / tinggiM.pow(2)
                val bmiFormatted = String.format("%.2f", bmi)

                val kategori = when {
                    bmi < 18.5 -> "Underweight"
                    bmi < 18 - 24.9 -> "Normal"
                    bmi < 25 - 29.9-> "Overweight"
                    else -> "Obesitas"
                }

                tvHasilBmi.text = "Hasil BMI: $bmiFormatted"
                tvKategoriBmi.text = "Kategori: $kategori"

            }
        }
    }
}
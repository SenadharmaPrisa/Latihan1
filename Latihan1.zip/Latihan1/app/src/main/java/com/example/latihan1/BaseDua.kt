package com.example.latihan1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BaseDua : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.basedua)

        val etScore = findViewById<EditText>(R.id.etScore)
        val btncheck = findViewById<Button>(R.id.btncheck)
        val tvGrade = findViewById<TextView>(R.id.tvGrade)
        val btnkembali = findViewById<Button>(R.id.btnkembali)

        btncheck.setOnClickListener {
            val scoreStr = etScore.text.toString()

            if (scoreStr.isNotEmpty()) {
                val score = scoreStr.toInt()

                val grade = if (score >= 90) {
                    "A"
                } else if (score >= 80) {
                    "B"
                } else if (score >= 70) {
                    "C"
                } else {
                    "D"
                }

                tvGrade.text = "Grade Kamu: $grade"
            }
        }

        btnkembali.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }
    }
}
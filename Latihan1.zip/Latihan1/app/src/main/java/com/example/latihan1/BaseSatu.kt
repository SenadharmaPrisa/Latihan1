package com.example.latihan1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BaseSatu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.basesatu)

        val name = "Prisa Senada"
        val age = 23
        val txtTampil = findViewById<TextView>(R.id.txt2)
        txtTampil.text = "Nama: $name, Umur: $age tahun"

        val btnback = findViewById<Button>(R.id.btnkembali)
        btnback.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }
    }
}